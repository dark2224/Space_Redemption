// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "TangibleActor.h"
#include "EmergencyLever.generated.h"

/**
 * 
 */
UCLASS()
class SPACE_REDEMPTION_API AEmergencyLever : public ATangibleActor
{
	GENERATED_BODY()
	
	
	
	
};
