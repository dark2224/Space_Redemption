#pragma once

UENUM(BlueprintType)
enum InteractionStatus{
Idle, Approaching, Interacting
};